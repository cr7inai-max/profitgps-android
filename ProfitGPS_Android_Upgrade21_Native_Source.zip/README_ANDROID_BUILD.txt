ProfitGPS Android native build based on Windows Upgrade 21 source/business logic.
Android-specific addition: native camera barcode scanning using mobile_scanner.
Purchase Supplier flow includes working New supplier -> Create & select supplier.
